#' @useDynLib GenoPop, .registration = TRUE
NULL
